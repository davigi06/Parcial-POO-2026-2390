package core.person;

import core.store.Libro;
import java.util.ArrayList;

/**
 *
 * @author dgbuelvas
 */
public class Autor extends Persona {

    private ArrayList<Libro> libros;

    public Autor(int id, String nombre, int telefono, String direccion) {
        super(id, nombre, telefono, direccion);
        this.libros = new ArrayList<>();
    }

    public boolean addLibro(Libro libro) {
        if (!libros.contains(libro)) {
            libros.add(libro);
            return true;
        }
        return false;
    }
}
