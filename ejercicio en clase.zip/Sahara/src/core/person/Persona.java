package core.person;

/**
 *
 * @author dgbuelvas
 */
public abstract class Persona {

    protected int id;
    protected String nombre;
    protected int telefono;
    protected String direccion;

    public Persona(int id, String nombre, int telefono, String direccion) {
        this.id = id;
        this.nombre = nombre;
        this.telefono = telefono;
        this.direccion = direccion;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
