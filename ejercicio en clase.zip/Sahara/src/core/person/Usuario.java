package core.person;

import core.store.Compra;
import core.store.Evaluacion;
import core.store.Libro;
import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 *
 * @author dgbuelvas
 */
public class Usuario extends Persona {

    private ArrayList<Compra> compras;
    private ArrayList<Evaluacion> evaluaciones;

    public Usuario(int id, String nombre, int telefono, String direccion) {
        super(id, nombre, telefono, direccion);
        this.compras = new ArrayList<>();
        this.evaluaciones = new ArrayList<>();
    }

    public boolean addCompra(Compra compra) {
        if (!compras.contains(compra)) {
            compras.add(compra);
            return true;
        }
        return false;
    }

    public void makeEvaluacion(Libro libro, LocalDateTime fecha, int estrellas, String comentario) {
        Evaluacion evaluacion = new Evaluacion(this, libro, fecha, estrellas, comentario);
        evaluaciones.add(evaluacion);
        libro.addEvaluacion(evaluacion);
    }

    public Evaluacion getEvaluacion(int indice) {
        return evaluaciones.get(indice);
    }

    public void like(Evaluacion evaluacion) {
        evaluacion.addLike();
    }

    public void dislike(Evaluacion evaluacion) {
        evaluacion.addDislike();
    }

    public int getTotalLikes() {
        int total = 0;
        for (Evaluacion evaluacion : evaluaciones) {
            total += evaluacion.getLikes();
        }
        return total;
    }

    public int getTotalDislikes() {
        int total = 0;
        for (Evaluacion evaluacion : evaluaciones) {
            total += evaluacion.getDislikes();
        }
        return total;
    }

    public void showInfo() {
        System.out.println("- ID: " + id);
        System.out.println("- Nombre: " + nombre);
        System.out.println("- Telefono: " + telefono);
        System.out.println("- Direccion: " + direccion);
        System.out.println("- Numero de Compras: " + compras.size());
        System.out.println("- Numero de Evaluaciones: " + evaluaciones.size());
    }
}
