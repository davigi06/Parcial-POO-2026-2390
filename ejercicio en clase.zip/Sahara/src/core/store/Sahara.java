package core.store;

import core.person.Usuario;
import java.util.ArrayList;
import java.util.Locale;

/**
 *
 * @author dgbuelvas
 */
public class Sahara {

    private ArrayList<Usuario> usuarios;
    private ArrayList<Libro> libros;
    private ArrayList<Bodega> bodegas;
    private ArrayList<Compra> compras;

    public Sahara() {
        this.usuarios = new ArrayList<>();
        this.libros = new ArrayList<>();
        this.bodegas = new ArrayList<>();
        this.compras = new ArrayList<>();
    }

    public boolean addUsuario(Usuario usuario) {
        if (!usuarios.contains(usuario)) {
            usuarios.add(usuario);
            return true;
        }
        return false;
    }

    public boolean addLibro(Libro libro) {
        if (!libros.contains(libro)) {
            libros.add(libro);
            return true;
        }
        return false;
    }

    public boolean addBodega(Bodega bodega) {
        if (!bodegas.contains(bodega)) {
            bodegas.add(bodega);
            return true;
        }
        return false;
    }

    public boolean addCompra(Usuario usuario, ArrayList<Libro> libros, ArrayList<Integer> unidades) {
        Compra compra = new Compra(usuario, libros, unidades);
        usuario.addCompra(compra);
        return compras.add(compra);
    }

    public Usuario getUsuario(int id) {
        for (Usuario usuario : usuarios) {
            if (usuario.getId() == id) {
                return usuario;
            }
        }
        return null;
    }

    public Libro getLibro(int id) {
        for (Libro libro : libros) {
            if (libro.getId() == id) {
                return libro;
            }
        }
        return null;
    }

    public Bodega getBodega(int indice) {
        return bodegas.get(indice);
    }

    public void showLibroMayorPromedioEstrellasEvaluacion() {
        Libro mayor = libros.get(0);
        for (Libro libro : libros) {
            if (libro.getPromedioEstrellas() > mayor.getPromedioEstrellas()) {
                mayor = libro;
            }
        }
        System.out.println("La informacion del libro que tiene el mayor promedio en estrellas de sus evaluaciones es:");
        mayor.showInfo();
        System.out.println();
    }

    public void showUsuarioMaxCompra() {
        Compra mayor = compras.get(0);
        for (Compra compra : compras) {
            if (compra.getTotal() > mayor.getTotal()) {
                mayor = compra;
            }
        }
        System.out.println("La informacion del usuario que registro la mayor compra es:");
        mayor.getUsuario().showInfo();
        System.out.println("- Mayor Compra: $" + String.format(Locale.US, "%.2f", mayor.getTotal()));
        System.out.println();
    }

    public void showUsuarioMaxLikes() {
        Usuario mayor = usuarios.get(0);
        for (Usuario usuario : usuarios) {
            if (usuario.getTotalLikes() > mayor.getTotalLikes()) {
                mayor = usuario;
            }
        }
        System.out.println("La informacion del usuario que tiene el mayor numero de likes en todas sus evaluaciones es:");
        mayor.showInfo();
        System.out.println("- Numero de Likes: " + mayor.getTotalLikes());
        System.out.println();
    }

    public void showUsuarioMaxDislikes() {
        Usuario mayor = usuarios.get(0);
        for (Usuario usuario : usuarios) {
            if (usuario.getTotalDislikes() > mayor.getTotalDislikes()) {
                mayor = usuario;
            }
        }
        System.out.println("La informacion del usuario que tiene el mayor numero de dislikes en todas sus evaluaciones es:");
        mayor.showInfo();
        System.out.println("- Numero de Dislikes: " + mayor.getTotalDislikes());
        System.out.println();
    }
}
