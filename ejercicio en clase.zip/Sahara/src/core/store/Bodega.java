package core.store;

import java.util.ArrayList;

/**
 *
 * @author dgbuelvas
 */
public class Bodega {

    private double latitud;
    private double longitud;
    private ArrayList<Libro> libros;
    private ArrayList<Integer> existencias;

    public Bodega(double latitud, double longitud) {
        this.latitud = latitud;
        this.longitud = longitud;
        this.libros = new ArrayList<>();
        this.existencias = new ArrayList<>();
    }

    public boolean addExistencias(Libro libro, int cantidad) {
        int indice = libros.indexOf(libro);
        if (indice == -1) {
            libros.add(libro);
            existencias.add(cantidad);
            libro.addBodega(this);
            return true;
        }
        existencias.set(indice, existencias.get(indice) + cantidad);
        return false;
    }

    public int getExistencias(Libro libro) {
        int indice = libros.indexOf(libro);
        if (indice == -1) {
            return 0;
        }
        return existencias.get(indice);
    }
}
