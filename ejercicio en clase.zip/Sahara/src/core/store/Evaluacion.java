package core.store;

import core.person.Usuario;
import java.time.LocalDateTime;

/**
 *
 * @author dgbuelvas
 */
public class Evaluacion {

    private Usuario autor;
    private Libro libro;
    private LocalDateTime fecha;
    private int estrellas;
    private String comentario;
    private int likes;
    private int dislikes;

    public Evaluacion(Usuario autor, Libro libro, LocalDateTime fecha, int estrellas, String comentario) {
        this.autor = autor;
        this.libro = libro;
        this.fecha = fecha;
        this.estrellas = estrellas;
        this.comentario = comentario;
        this.likes = 0;
        this.dislikes = 0;
    }

    public int getEstrellas() {
        return estrellas;
    }

    public int getLikes() {
        return likes;
    }

    public int getDislikes() {
        return dislikes;
    }

    public void addLike() {
        likes++;
    }

    public void addDislike() {
        dislikes++;
    }
}
