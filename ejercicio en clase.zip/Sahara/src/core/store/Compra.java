package core.store;

import core.person.Usuario;
import java.util.ArrayList;

/**
 *
 * @author dgbuelvas
 */
public class Compra {

    private Usuario usuario;
    private ArrayList<Libro> libros;
    private ArrayList<Integer> unidades;
    private ArrayList<Bodega> bodegas;
    private double total;

    public Compra(Usuario usuario, ArrayList<Libro> libros, ArrayList<Integer> unidades) {
        this.usuario = usuario;
        this.libros = libros;
        this.unidades = unidades;
        this.bodegas = new ArrayList<>();
        this.total = 0;
        for (int i = 0; i < libros.size(); i++) {
            total += libros.get(i).getPrecio() * unidades.get(i);
            for (Bodega bodega : libros.get(i).getBodegas()) {
                if (!bodegas.contains(bodega)) {
                    bodegas.add(bodega);
                }
            }
        }
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public double getTotal() {
        return total;
    }
}
