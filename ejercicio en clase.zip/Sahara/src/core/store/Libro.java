package core.store;

import core.person.Autor;
import java.util.ArrayList;
import java.util.Locale;

/**
 *
 * @author dgbuelvas
 */
public class Libro {

    private int id;
    private String titulo;
    private ArrayList<Autor> autores;
    private String editorial;
    private ArrayList<Integer> ediciones;
    private String isbn;
    private String caracteristicas;
    private Genero genero;
    private double precio;
    private ArrayList<Bodega> bodegas;
    private ArrayList<Evaluacion> evaluaciones;

    public Libro(int id, String titulo, ArrayList<Autor> autores, String editorial, ArrayList<Integer> ediciones,
            String isbn, String caracteristicas, Genero genero, double precio) {
        this.id = id;
        this.titulo = titulo;
        this.autores = autores;
        this.editorial = editorial;
        this.ediciones = ediciones;
        this.isbn = isbn;
        this.caracteristicas = caracteristicas;
        this.genero = genero;
        this.precio = precio;
        this.bodegas = new ArrayList<>();
        this.evaluaciones = new ArrayList<>();
        for (Autor autor : autores) {
            autor.addLibro(this);
        }
    }

    public int getId() {
        return id;
    }

    public double getPrecio() {
        return precio;
    }

    public ArrayList<Bodega> getBodegas() {
        return bodegas;
    }

    public boolean addBodega(Bodega bodega) {
        if (!bodegas.contains(bodega)) {
            bodegas.add(bodega);
            return true;
        }
        return false;
    }

    public boolean addEvaluacion(Evaluacion evaluacion) {
        if (!evaluaciones.contains(evaluacion)) {
            evaluaciones.add(evaluacion);
            return true;
        }
        return false;
    }

    public int getTotalExistencias() {
        int total = 0;
        for (Bodega bodega : bodegas) {
            total += bodega.getExistencias(this);
        }
        return total;
    }

    public double getPromedioEstrellas() {
        if (evaluaciones.isEmpty()) {
            return 0;
        }
        double suma = 0;
        for (Evaluacion evaluacion : evaluaciones) {
            suma += evaluacion.getEstrellas();
        }
        return suma / evaluaciones.size();
    }

    public void showInfo() {
        System.out.println("- ID: " + id);
        System.out.println("- Titulo: " + titulo);
        System.out.println("- Autores: " + autores);
        System.out.println("- Editorial: " + editorial);
        System.out.println("- Ediciones: " + ediciones);
        System.out.println("- ISBN: " + isbn);
        System.out.println("- Caracteristicas: " + caracteristicas);
        System.out.println("- Genero: " + genero);
        System.out.println("- Precio: $" + String.format(Locale.US, "%.2f", precio));
        System.out.println("- Numero de Bodegas: " + bodegas.size());
        System.out.println("- Total de Existencias: " + getTotalExistencias());
        System.out.println("- Numero de Evaluaciones: " + evaluaciones.size());
        System.out.println("- Estrellas Promedio: " + String.format(Locale.US, "%.2f", getPromedioEstrellas()));
    }
}
