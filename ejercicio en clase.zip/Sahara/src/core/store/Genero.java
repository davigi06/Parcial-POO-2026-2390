package core.store;

/**
 *
 * @author dgbuelvas
 */
public enum Genero {
    AVENTURA,
    FANTASIA,
    HISTORICO,
    ROMANCE,
    THRILLER
}
