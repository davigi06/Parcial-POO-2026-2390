/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab1estructuradedatos;

/**
 *
 * @author sercu
 */
public class Lab1EstructuradeDatos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MainMenu frame = new MainMenu();
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }
    
}
