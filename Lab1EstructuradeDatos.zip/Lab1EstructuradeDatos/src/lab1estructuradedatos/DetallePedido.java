/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab1estructuradedatos;

/**
 *
 * @author HP
 */
public class DetallePedido {
    private int idPedido;
    private int idPlato;
    private int cantidad;
    private double precio;

    public DetallePedido(int idPedido, int idPlato, int cantidad, double precio) {
        this.idPedido = idPedido;
        this.idPlato = idPlato;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public int getIdPlato() {
        return idPlato;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public double calcularSubtotal() {
        return cantidad * precio;
    }

    @Override
    public String toString() {
        return idPedido + "," + idPlato + "," + cantidad + "," + precio;
    }
}
