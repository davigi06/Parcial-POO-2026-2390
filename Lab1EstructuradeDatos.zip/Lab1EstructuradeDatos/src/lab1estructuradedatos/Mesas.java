/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package lab1estructuradedatos;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;

public class Mesas extends javax.swing.JFrame {
    JTextField idField;
    JTextField capacidadField;
    JComboBox<String> estadoBox;

    JTable tabla;
    DefaultTableModel modelo;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Mesas.class.getName());

    /**
     * Creates new form Mesas
     */
   public Mesas() {

        setTitle("Gestión de Mesas");
        setSize(650,450);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        Color fondo = new Color(245,245,245);
        getContentPane().setBackground(fondo);

        // BARRA SUPERIOR
        JPanel barra = new JPanel();
        barra.setBackground(new Color(33,56,89));
        barra.setPreferredSize(new Dimension(600,60));

        JLabel titulo = new JLabel("GESTIÓN DE MESAS");
        titulo.setFont(new Font("Arial",Font.BOLD,18));
        titulo.setForeground(Color.WHITE);

        barra.add(titulo);
        add(barra,BorderLayout.NORTH);

        // PANEL CENTRAL
        JPanel centro = new JPanel();
        centro.setBackground(fondo);
        centro.setLayout(new BorderLayout());

        // FORMULARIO
        JPanel formulario = new JPanel(new GridLayout(3,2,10,10));
        formulario.setBorder(BorderFactory.createEmptyBorder(20,40,20,40));
        formulario.setBackground(fondo);

        JLabel id = new JLabel("ID Mesa:");
        idField = new JTextField();

        JLabel cap = new JLabel("Capacidad:");
        capacidadField = new JTextField();

        JLabel estado = new JLabel("Estado:");
        estadoBox = new JComboBox<>(new String[]{"LIBRE","OCUPADA","RESERVADA"});

        formulario.add(id);
        formulario.add(idField);
        formulario.add(cap);
        formulario.add(capacidadField);
        formulario.add(estado);
        formulario.add(estadoBox);

        // BOTONES
        JPanel botones = new JPanel();
        botones.setBackground(fondo);

        JButton agregar = new JButton("Agregar");
        JButton actualizar = new JButton("Actualizar");
        JButton eliminar = new JButton("Eliminar");

        agregar.setBackground(new Color(52,120,246));
        agregar.setForeground(Color.WHITE);

        botones.add(agregar);
        botones.add(actualizar);
        botones.add(eliminar);

        // PANEL SUPERIOR (FORMULARIO + BOTONES)
        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setBackground(fondo);

        panelSuperior.add(formulario,BorderLayout.NORTH);
        panelSuperior.add(botones,BorderLayout.SOUTH);

        // TABLA
        modelo = new DefaultTableModel();
        modelo.addColumn("ID Mesa");
        modelo.addColumn("Capacidad");
        modelo.addColumn("Estado");

        tabla = new JTable(modelo);
        tabla.setRowHeight(25);

        JScrollPane scroll = new JScrollPane(tabla);

        centro.add(panelSuperior,BorderLayout.NORTH);
        centro.add(scroll,BorderLayout.CENTER);

        add(centro,BorderLayout.CENTER);

        // EVENTOS
        agregar.addActionListener(e -> agregarMesa());
        actualizar.addActionListener(e -> actualizarMesa());
        eliminar.addActionListener(e -> eliminarMesa());

        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                seleccionarMesa();
            }
        });

        cargarMesas();
    }

    private void agregarMesa(){

        String id = idField.getText().trim();
        String capacidad = capacidadField.getText().trim();
        String estado = estadoBox.getSelectedItem().toString();

        if(id.isEmpty() || capacidad.isEmpty()){
            JOptionPane.showMessageDialog(this,"Campos vacíos");
            return;
        }

        try{
            Integer.parseInt(capacidad);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"Capacidad debe ser numérica");
            return;
        }

        if(idExiste(id)){
            JOptionPane.showMessageDialog(this,"ID ya existe");
            return;
        }

        modelo.addRow(new Object[]{id,capacidad,estado});
        guardarArchivo();
        limpiarCampos();
    }

    private void actualizarMesa(){

        int fila = tabla.getSelectedRow();

        if(fila == -1){
            JOptionPane.showMessageDialog(this,"Seleccione una mesa");
            return;
        }

        modelo.setValueAt(idField.getText(),fila,0);
        modelo.setValueAt(capacidadField.getText(),fila,1);
        modelo.setValueAt(estadoBox.getSelectedItem(),fila,2);

        guardarArchivo();
        limpiarCampos();
    }

    private void eliminarMesa(){

        int fila = tabla.getSelectedRow();

        if(fila == -1){
            JOptionPane.showMessageDialog(this,"Seleccione una mesa");
            return;
        }

        int confirmar = JOptionPane.showConfirmDialog(this,"¿Eliminar mesa?");

        if(confirmar == JOptionPane.YES_OPTION){
            modelo.removeRow(fila);
            guardarArchivo();
        }
    }

    private void seleccionarMesa(){

        int fila = tabla.getSelectedRow();

        idField.setText(modelo.getValueAt(fila,0).toString());
        capacidadField.setText(modelo.getValueAt(fila,1).toString());
        estadoBox.setSelectedItem(modelo.getValueAt(fila,2).toString());
    }

    private boolean idExiste(String id){

        for(int i=0;i<modelo.getRowCount();i++){
            if(modelo.getValueAt(i,0).toString().equals(id)){
                return true;
            }
        }
        return false;
    }

    private void guardarArchivo(){

        try{

            BufferedWriter bw = new BufferedWriter(new FileWriter("Mesas.txt"));

            for(int i=0;i<modelo.getRowCount();i++){

                bw.write(
                        modelo.getValueAt(i,0)+","+
                        modelo.getValueAt(i,1)+","+
                        modelo.getValueAt(i,2)
                );

                bw.newLine();
            }

            bw.close();

        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"Error guardando archivo");
        }
    }

    private void cargarMesas(){

        try{

            File archivo = new File("Mesas.txt");

            if(!archivo.exists()) return;

            BufferedReader br = new BufferedReader(new FileReader(archivo));

            String linea;

            while((linea = br.readLine()) != null){

                String[] datos = linea.split(",");

                modelo.addRow(new Object[]{
                        datos[0],
                        datos[1],
                        datos[2]
                });
            }

            br.close();

        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"Error cargando archivo");
        }
    }

    private void limpiarCampos(){
        idField.setText("");
        capacidadField.setText("");
        estadoBox.setSelectedIndex(0);
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Mesas().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
