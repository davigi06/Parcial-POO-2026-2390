/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package lab1estructuradedatos;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;

public class Platos extends javax.swing.JFrame {
    JTextField idField;
    JTextField nombreField;
    JTextField precioField;

    JTable tabla;
    DefaultTableModel modelo;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Platos.class.getName());

    /**
     * Creates new form Platos
     */
public Platos() {

        setTitle("Gestión de Platos");
        setSize(650,450);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        Color fondo = new Color(245,245,245);
        getContentPane().setBackground(fondo);

        // BARRA SUPERIOR
        JPanel barra = new JPanel();
        barra.setBackground(new Color(33,56,89));
        barra.setPreferredSize(new Dimension(600,60));

        JLabel titulo = new JLabel("GESTIÓN DE PLATOS");
        titulo.setFont(new Font("Arial",Font.BOLD,18));
        titulo.setForeground(Color.WHITE);

        barra.add(titulo);
        add(barra,BorderLayout.NORTH);

        // PANEL CENTRAL
        JPanel centro = new JPanel();
        centro.setBackground(fondo);
        centro.setLayout(new BorderLayout());

        // FORMULARIO
        JPanel formulario = new JPanel(new GridLayout(3,2,10,10));
        formulario.setBorder(BorderFactory.createEmptyBorder(20,40,20,40));
        formulario.setBackground(fondo);

        JLabel id = new JLabel("ID:");
        idField = new JTextField();

        JLabel nombre = new JLabel("Nombre:");
        nombreField = new JTextField();

        JLabel precio = new JLabel("Precio:");
        precioField = new JTextField();

        formulario.add(id);
        formulario.add(idField);
        formulario.add(nombre);
        formulario.add(nombreField);
        formulario.add(precio);
        formulario.add(precioField);

        // BOTONES
        JPanel botones = new JPanel();
        botones.setBackground(fondo);

        JButton agregar = new JButton("Agregar");
        JButton actualizar = new JButton("Actualizar");
        JButton eliminar = new JButton("Eliminar");

        agregar.setBackground(new Color(52,120,246));
        agregar.setForeground(Color.WHITE);
        
        actualizar.setBackground(new Color(60,170,90));
        actualizar.setForeground(Color.WHITE);
        
        eliminar.setBackground(new Color(200,60,60));
        eliminar.setForeground(Color.WHITE);

        botones.add(agregar);
        botones.add(actualizar);
        botones.add(eliminar);

        // TABLA
        modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        modelo.addColumn("Precio");

        tabla = new JTable(modelo);
        tabla.setRowHeight(25);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setPreferredSize(new Dimension(600,180));

        // ORGANIZACIÓN
        centro.add(formulario,BorderLayout.NORTH);
        centro.add(botones,BorderLayout.CENTER);
        centro.add(scroll,BorderLayout.SOUTH);

        add(centro,BorderLayout.CENTER);

        agregar.addActionListener(e -> agregarPlato());
        actualizar.addActionListener(e -> actualizarPlato());
        eliminar.addActionListener(e -> eliminarPlato());
        
        tabla.getSelectionModel().addListSelectionListener(e -> {

    int fila = tabla.getSelectedRow();

    if(fila >= 0){

        idField.setText(modelo.getValueAt(fila,0).toString());
        nombreField.setText(modelo.getValueAt(fila,1).toString());
        precioField.setText(modelo.getValueAt(fila,2).toString());

    }

});

        cargarArchivo();
    }

    // AGREGAR PLATO
    private void agregarPlato(){

        String id = idField.getText();
        String nombre = nombreField.getText();
        String precio = precioField.getText();

        if(id.isEmpty() || nombre.isEmpty() || precio.isEmpty()){
            JOptionPane.showMessageDialog(this,"Complete todos los campos");
            return;
        }

        try{
            Double.parseDouble(precio);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"El precio debe ser numérico");
            return;
        }

        if(idDuplicado(id)){
            JOptionPane.showMessageDialog(this,"El ID ya existe");
            return;
        }

        modelo.addRow(new Object[]{id,nombre,precio});

        guardarArchivo();

        limpiarCampos();
    }

    private void actualizarPlato(){

    int fila = tabla.getSelectedRow();

    if(fila == -1){
        JOptionPane.showMessageDialog(this,"Seleccione un plato para actualizar");
        return;
    }

    String id = idField.getText();
    String nombre = nombreField.getText();
    String precio = precioField.getText();

    if(id.isEmpty() || nombre.isEmpty() || precio.isEmpty()){
        JOptionPane.showMessageDialog(this,"Complete todos los campos");
        return;
    }

    try{
        Double.parseDouble(precio);
    }catch(Exception e){
        JOptionPane.showMessageDialog(this,"El precio debe ser numérico");
        return;
    }

    modelo.setValueAt(id,fila,0);
    modelo.setValueAt(nombre,fila,1);
    modelo.setValueAt(precio,fila,2);

    guardarArchivo();

    limpiarCampos();

    JOptionPane.showMessageDialog(this,"Plato actualizado");

    
}
    
    
    // ELIMINAR PLATO
    private void eliminarPlato(){

        int fila = tabla.getSelectedRow();

        if(fila >= 0){

            int confirm = JOptionPane.showConfirmDialog(this,"¿Eliminar plato?");

            if(confirm == JOptionPane.YES_OPTION){
                modelo.removeRow(fila);
                guardarArchivo();
            }

        }else{
            JOptionPane.showMessageDialog(this,"Seleccione un plato");
        }

    }

    // VERIFICAR ID DUPLICADO
    private boolean idDuplicado(String id){

        for(int i=0;i<modelo.getRowCount();i++){

            if(modelo.getValueAt(i,0).toString().equals(id)){
                return true;
            }

        }

        return false;
    }

    // LIMPIAR CAMPOS
    private void limpiarCampos(){

        idField.setText("");
        nombreField.setText("");
        precioField.setText("");

    }

    // GUARDAR ARCHIVO
    private void guardarArchivo(){

        try{

            PrintWriter pw = new PrintWriter(new FileWriter("Platos.txt"));

            for(int i=0;i<modelo.getRowCount();i++){

                String id = modelo.getValueAt(i,0).toString();
                String nombre = modelo.getValueAt(i,1).toString();
                String precio = modelo.getValueAt(i,2).toString();

                pw.println(id + "," + nombre + "," + precio);

            }

            pw.close();

        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"Error guardando archivo");
        }

    }

    // CARGAR ARCHIVO
    private void cargarArchivo(){

        try{

            BufferedReader br = new BufferedReader(new FileReader("Platos.txt"));

            String linea;

            while((linea = br.readLine()) != null){

                String[] datos = linea.split(",");

                modelo.addRow(new Object[]{
                        datos[0],
                        datos[1],
                        datos[2]
                });

            }

            br.close();

        }catch(Exception e){
            System.out.println("Archivo no encontrado");
        }

    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Platos().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
