/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package lab1estructuradedatos;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;

public class Pedidos extends javax.swing.JFrame {
    JTextField idPedido;
    JTextField idMesa;
    JTable tabla;
    DefaultTableModel modelo;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Pedidos.class.getName());
private void guardarDetallePedido(DetallePedido detalle) {

    try {

        java.io.FileWriter fw = new java.io.FileWriter("detallePedidos.txt", true);
        java.io.PrintWriter pw = new java.io.PrintWriter(fw);

        pw.println(detalle.toString());

        pw.close();

    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(null, "Error al guardar detalle");
    }

}
    /**
     * Creates new form Pedidos
     */
    public Pedidos() {

        setTitle("Pedidos");
        setSize(650,450);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        Color fondo = new Color(245,245,245);
        getContentPane().setBackground(fondo);

        // BARRA SUPERIOR
        JPanel barra = new JPanel();
        barra.setBackground(new Color(33,56,89));
        barra.setPreferredSize(new Dimension(600,60));

        JLabel titulo = new JLabel("GESTIÓN DE PEDIDOS");
        titulo.setFont(new Font("Arial",Font.BOLD,18));
        titulo.setForeground(Color.WHITE);

        barra.add(titulo);
        add(barra,BorderLayout.NORTH);

        // PANEL CENTRAL
        JPanel centro = new JPanel();
        centro.setBackground(fondo);
        centro.setLayout(new BorderLayout());

        // FORMULARIO
        JPanel formulario = new JPanel(new GridLayout(2,2,10,10));
        formulario.setBorder(BorderFactory.createEmptyBorder(20,40,20,40));
        formulario.setBackground(fondo);

        JLabel pedido = new JLabel("ID Pedido:");
        idPedido = new JTextField();

        JLabel mesa = new JLabel("ID Mesa:");
        idMesa = new JTextField();

        formulario.add(pedido);
        formulario.add(idPedido);
        formulario.add(mesa);
        formulario.add(idMesa);

        // BOTONES
        JPanel botones = new JPanel();
        botones.setBackground(fondo);

        JButton crear = new JButton("Crear Pedido");

        crear.setBackground(new Color(52,120,246));
        crear.setForeground(Color.WHITE);
        
        JButton agregarPlato = new JButton("Agregar Plato");
        
        agregarPlato.setBackground(new Color(46,204,113));
        agregarPlato.setForeground(Color.WHITE);
        
        JButton cancelar = new JButton("Cancelar Pedido");
        
        cancelar.setBackground(new Color(231,76,60));
        cancelar.setForeground(Color.WHITE);

        botones.add(crear);
        botones.add(agregarPlato);
        botones.add(cancelar);
        
        // TABLA
        modelo = new DefaultTableModel();
        modelo.addColumn("ID Pedido");
        modelo.addColumn("ID Mesa");
        modelo.addColumn("FechaHora");
        modelo.addColumn("Estado");

        tabla = new JTable(modelo);
        tabla.setRowHeight(25);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setPreferredSize(new Dimension(600,180));

        // ORGANIZACIÓN
        centro.add(formulario,BorderLayout.NORTH);
        centro.add(botones,BorderLayout.CENTER);
        centro.add(scroll,BorderLayout.SOUTH);

        add(centro,BorderLayout.CENTER);

        crear.addActionListener(e -> crearPedido());
        agregarPlato.addActionListener(e -> agregarPlatoPedido());
        cancelar.addActionListener(e -> cancelarPedido());
        
        cargarArchivo();
    }

    // CREAR PEDIDO
    private void crearPedido(){

        String pedido = idPedido.getText();
        String mesa = idMesa.getText();

        if(pedido.isEmpty() || mesa.isEmpty()){
            JOptionPane.showMessageDialog(this,"Complete todos los campos");
            return;
        }
        if(!mesaExiste(mesa)){
            JOptionPane.showMessageDialog(this,"La mesa no existe");
            return;
        }
        if(idDuplicado(pedido)){
            JOptionPane.showMessageDialog(this,"El ID del pedido ya existe");
            return;
        }

        String fechaHora = java.time.LocalDateTime.now()
                .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));

        modelo.addRow(new Object[]{
                pedido,
                mesa,
                fechaHora,
                "ABIERTO"
        });

        guardarArchivo();

        idPedido.setText("");
        idMesa.setText("");
    }

    private void cancelarPedido(){

    int fila = tabla.getSelectedRow();

    if(fila == -1){
        JOptionPane.showMessageDialog(this,"Seleccione un pedido");
        return;
    }

    String estado = modelo.getValueAt(fila,3).toString();

    if(estado.equals("CERRADO")){
        JOptionPane.showMessageDialog(this,"No se puede cancelar un pedido cerrado");
        return;
    }

    modelo.setValueAt("CANCELADO", fila, 3);

    guardarArchivo();

    JOptionPane.showMessageDialog(this,"Pedido cancelado correctamente");
}
    
    private void agregarPlatoPedido(){

    try{

        int fila = tabla.getSelectedRow();

        if(fila == -1){
            JOptionPane.showMessageDialog(this,"Seleccione un pedido");
            return;
        }

        int idPedido = Integer.parseInt(
                modelo.getValueAt(fila,0).toString()
        );

        int idPlato = Integer.parseInt(
                JOptionPane.showInputDialog("ID del plato")
        );

        String[] datosPlato = obtenerDatosPlato(idPlato);

        if(datosPlato == null){
            JOptionPane.showMessageDialog(this,"El plato no existe");
            return;
        }

        String nombrePlato = datosPlato[1];
        double precio = Double.parseDouble(datosPlato[2]);

        JOptionPane.showMessageDialog(this,
                "Plato encontrado:\n" +
                nombrePlato +
                "\nPrecio: " + precio
        );

        int cantidad = Integer.parseInt(
                JOptionPane.showInputDialog("Cantidad")
        );

        DetallePedido detalle = new DetallePedido(idPedido,idPlato,cantidad,precio);

        guardarDetallePedido(detalle);

        JOptionPane.showMessageDialog(this,"Plato agregado al pedido");

    }catch(Exception e){

        JOptionPane.showMessageDialog(this,"Datos inválidos");

    }

}
    private double obtenerPrecioPlato(int idPlato){

    try{

        BufferedReader br = new BufferedReader(new FileReader("Platos.txt"));
        String linea;

        while((linea = br.readLine()) != null){

            String[] datos = linea.split(",");

            int id = Integer.parseInt(datos[0]);
            double precio = Double.parseDouble(datos[2]);

            if(id == idPlato){
                br.close();
                return precio;
            }

        }

        br.close();

    }catch(Exception e){
        JOptionPane.showMessageDialog(this,"Error leyendo Platos.txt");
    }

    return -1; // plato no encontrado
}
    private String[] obtenerDatosPlato(int idPlato){

    try{

        BufferedReader br = new BufferedReader(new FileReader("Platos.txt"));
        String linea;

        while((linea = br.readLine()) != null){

            String[] datos = linea.split(",");

            int id = Integer.parseInt(datos[0]);

            if(id == idPlato){
                br.close();
                return datos;
            }

        }

        br.close();

    }catch(Exception e){
        JOptionPane.showMessageDialog(this,"Error leyendo Platos.txt");
    }

    return null;
}
    // VALIDAR ID DUPLICADO
    private boolean idDuplicado(String id){

        for(int i=0;i<modelo.getRowCount();i++){

            if(modelo.getValueAt(i,0).toString().equals(id)){
                return true;
            }

        }

        return false;
    }

    private boolean mesaExiste(String idMesa){

    try{

        BufferedReader br = new BufferedReader(new FileReader("Mesas.txt"));

        String linea;

        while((linea = br.readLine()) != null){

            String[] datos = linea.split(",");

            if(datos[0].equals(idMesa)){
                br.close();
                return true;
            }

        }

        br.close();

    }catch(Exception e){
        JOptionPane.showMessageDialog(this,"Error leyendo Mesas.txt");
    }

    return false;
}
    
    // GUARDAR ARCHIVO
    private void guardarArchivo(){

        try{

            PrintWriter pw = new PrintWriter(new FileWriter("Pedidos.txt"));

            for(int i=0;i<modelo.getRowCount();i++){

                String id = modelo.getValueAt(i,0).toString();
                String mesa = modelo.getValueAt(i,1).toString();
                String fecha = modelo.getValueAt(i,2).toString();
                String estado = modelo.getValueAt(i,3).toString();

                pw.println(id + "," + mesa + "," + fecha + "," + estado);
            }

            pw.close();

        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"Error guardando archivo");
        }

    }

    // CARGAR ARCHIVO
    private void cargarArchivo(){

        try{

            BufferedReader br = new BufferedReader(new FileReader("Pedidos.txt"));

            String linea;

            while((linea = br.readLine()) != null){

                String[] datos = linea.split(",");

                modelo.addRow(new Object[]{
                        datos[0],
                        datos[1],
                        datos[2],
                        datos[3]
                });

            }

            br.close();

        }catch(Exception e){
            System.out.println("Archivo no encontrado");
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Pedidos().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
