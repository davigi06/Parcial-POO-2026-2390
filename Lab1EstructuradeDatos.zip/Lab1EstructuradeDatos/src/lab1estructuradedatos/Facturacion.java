/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package lab1estructuradedatos;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;

public class Facturacion extends javax.swing.JFrame {
    JTextField idFactura;
    JTextField idPedido;
    JTextField subtotal;
    JTextField propina;
    JTextField total;

    JTable tabla;
    DefaultTableModel modelo;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Facturacion.class.getName());

    /**
     * Creates new form Facturacion
     */
    public Facturacion() {

        setTitle("Facturación");
        setSize(650,450);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        Color fondo = new Color(245,245,245);
        getContentPane().setBackground(fondo);

        // BARRA SUPERIOR
        JPanel barra = new JPanel();
        barra.setBackground(new Color(33,56,89));
        barra.setPreferredSize(new Dimension(600,60));

        JLabel titulo = new JLabel("FACTURACIÓN");
        titulo.setFont(new Font("Arial",Font.BOLD,18));
        titulo.setForeground(Color.WHITE);

        barra.add(titulo);
        add(barra,BorderLayout.NORTH);

        // PANEL CENTRAL
        JPanel centro = new JPanel();
        centro.setBackground(fondo);
        centro.setLayout(new BorderLayout());

        // FORMULARIO
        JPanel formulario = new JPanel(new GridLayout(5,2,10,10));
        formulario.setBorder(BorderFactory.createEmptyBorder(20,40,20,40));
        formulario.setBackground(fondo);

        JLabel factura = new JLabel("ID Factura:");
        idFactura = new JTextField();

        JLabel pedido = new JLabel("ID Pedido:");
        idPedido = new JTextField();

        JLabel sub = new JLabel("Subtotal:");
        subtotal = new JTextField();
        subtotal.setEditable(false);

        JLabel prop = new JLabel("Propina:");
        propina = new JTextField();

        JLabel tot = new JLabel("Total:");
        total = new JTextField();
        total.setEditable(false);

        formulario.add(factura);
        formulario.add(idFactura);
        formulario.add(pedido);
        formulario.add(idPedido);
        formulario.add(sub);
        formulario.add(subtotal);
        formulario.add(prop);
        formulario.add(propina);
        formulario.add(tot);
        formulario.add(total);

        // BOTONES
        JPanel botones = new JPanel();
        botones.setBackground(fondo);

        JButton calcular = new JButton("Calcular Total");
        calcular.setBackground(new Color(52,120,246));
        calcular.setForeground(Color.WHITE);

        JButton generar = new JButton("Generar Factura");
        generar.setBackground(new Color(52,120,246));
        generar.setForeground(Color.WHITE);

        botones.add(calcular);
        botones.add(generar);

        // TABLA
        modelo = new DefaultTableModel();
        modelo.addColumn("ID Factura");
        modelo.addColumn("ID Pedido");
        modelo.addColumn("Fecha");
        modelo.addColumn("Subtotal");
        modelo.addColumn("Propina");
        modelo.addColumn("Total");

        tabla = new JTable(modelo);
        tabla.setRowHeight(25);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setPreferredSize(new Dimension(600,150));

        // PANEL SUPERIOR (formulario + botones)
        JPanel panelSuperior = new JPanel();
        panelSuperior.setLayout(new BorderLayout());
        panelSuperior.setBackground(fondo);

        panelSuperior.add(formulario, BorderLayout.CENTER);
        panelSuperior.add(botones, BorderLayout.SOUTH);

// ORGANIZACIÓN
centro.add(panelSuperior, BorderLayout.NORTH);
centro.add(scroll, BorderLayout.CENTER);

        add(centro,BorderLayout.CENTER);

        calcular.addActionListener(e -> calcularTotal());
        generar.addActionListener(e -> generarFactura());
    }

    // CALCULAR SUBTOTAL DESDE detallePedidos.txt
    private double calcularSubtotalPedido(String idPedido){

        double subtotal = 0;

        try{

            BufferedReader br = new BufferedReader(new FileReader("detallePedidos.txt"));
            String linea;

            while((linea = br.readLine()) != null){

                String[] datos = linea.split(",");

                String pedido = datos[0];
                int cantidad = Integer.parseInt(datos[2]);
                double precio = Double.parseDouble(datos[3]);

                if(pedido.equals(idPedido)){
                    subtotal += cantidad * precio;
                }

            }

            br.close();

        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"Error leyendo detallePedidos.txt");
        }

        return subtotal;
    }

    // CALCULAR TOTAL
    private void calcularTotal(){

        try{

            String idP = idPedido.getText();

            double sub = calcularSubtotalPedido(idP);

            subtotal.setText(String.valueOf(sub));

            double pro = Double.parseDouble(propina.getText());

            double t = sub + pro;

            total.setText(String.valueOf(t));

        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"Datos inválidos");
        }
    }

    // GENERAR FACTURA
    private void generarFactura(){

        String idF = idFactura.getText();
        String idP = idPedido.getText();
        String sub = subtotal.getText();
        String pro = propina.getText();
        String tot = total.getText();
        
        if(idF.isEmpty() || idP.isEmpty() || sub.isEmpty() || pro.isEmpty() || tot.isEmpty()){
             JOptionPane.showMessageDialog(this,"Complete todos los campos");
             return;
}
        String fecha = java.time.LocalDateTime.now()
        .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        modelo.addRow(new Object[]{idF,idP,fecha,sub,pro,tot});

        try{

            BufferedWriter bw = new BufferedWriter(new FileWriter("Facturas.txt", true));

            bw.write(idF + "," + idP + "," + fecha + "," + sub + "," + pro + "," + tot);
            bw.newLine();

            bw.close();

            cerrarPedido(idP);

            JOptionPane.showMessageDialog(this,"Factura generada y pedido cerrado");

        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"Error guardando factura");
        }

    }

    // CAMBIAR ESTADO DEL PEDIDO A CERRADO
    private void cerrarPedido(String idPedido){

        try{

            File inputFile = new File("Pedidos.txt");
            File tempFile = new File("PedidosTemp.txt");

            BufferedReader br = new BufferedReader(new FileReader(inputFile));
            PrintWriter pw = new PrintWriter(new FileWriter(tempFile));

            String linea;

            while((linea = br.readLine()) != null){

                String[] datos = linea.split(",");

                if(datos[0].equals(idPedido)){
                    datos[3] = "CERRADO";
                }

                pw.println(datos[0]+","+datos[1]+","+datos[2]+","+datos[3]);
            }

            br.close();
            pw.close();

            inputFile.delete();
            tempFile.renameTo(inputFile);

        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"Error cerrando pedido");
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Facturacion().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
