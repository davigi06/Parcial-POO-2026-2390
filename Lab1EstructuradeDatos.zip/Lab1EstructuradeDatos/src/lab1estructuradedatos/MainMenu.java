/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package lab1estructuradedatos;

import java.awt.BorderLayout;
import javax.swing.*;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.*;
import java.awt.event.*;

public class MainMenu extends javax.swing.JFrame {
    
    JButton platosBtn;
    JButton mesasBtn;
    JButton pedidosBtn;
    JButton reportesBtn;
    JButton salirBtn;
    JButton FacturacionBtn;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MainMenu.class.getName());

    /**
     * Creates new form MainMenu
     */
    public MainMenu(){
setTitle("Sistema Restaurante");
        setSize(1000,600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        crearHeader();
        crearMenuLateral();
        crearDashboard();
    }

    private void crearHeader(){

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(25,30,45));
        header.setPreferredSize(new Dimension(1000,70));

        JLabel titulo = new JLabel("SISTEMA DE GESTIÓN - RESTAURANTE DONDE JUANCHO");
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("Segoe UI",Font.BOLD,20));
        titulo.setBorder(BorderFactory.createEmptyBorder(0,20,0,0));

        header.add(titulo, BorderLayout.WEST);

        add(header, BorderLayout.NORTH);
    }

    private void crearMenuLateral(){

        JPanel menu = new JPanel();
        menu.setBackground(new Color(35,40,60));
        menu.setPreferredSize(new Dimension(220,600));
        menu.setLayout(new BoxLayout(menu, BoxLayout.Y_AXIS));

        JLabel logo = new JLabel("JUANCHO");
        logo.setFont(new Font("Segoe UI",Font.BOLD,24));
        logo.setForeground(Color.WHITE);
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel sub = new JLabel("Restaurant System");
        sub.setFont(new Font("Segoe UI",Font.PLAIN,12));
        sub.setForeground(new Color(180,180,180));
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);

        menu.add(Box.createVerticalStrut(30));
        menu.add(logo);
        menu.add(sub);
        menu.add(Box.createVerticalStrut(40));

        platosBtn = crearBotonMenu("GESTION DE PLATOS");
        mesasBtn = crearBotonMenu("GESTION DE MESAS");
        pedidosBtn = crearBotonMenu("GESTION DE PEDIDOS");
        reportesBtn = crearBotonMenu("REPORTES");
        FacturacionBtn = crearBotonMenu("FACTURACION");
        salirBtn = crearBotonSalir("SALIR");

        menu.add(platosBtn);
        menu.add(Box.createVerticalStrut(10));
        menu.add(mesasBtn);
        menu.add(Box.createVerticalStrut(10));
        menu.add(pedidosBtn);
        menu.add(Box.createVerticalStrut(10));
        menu.add(reportesBtn);
        menu.add(Box.createVerticalStrut(10));
        menu.add(FacturacionBtn);

        menu.add(Box.createVerticalGlue());

        menu.add(salirBtn);
        menu.add(Box.createVerticalStrut(20));

        add(menu, BorderLayout.WEST);

        // ACCIONES (las tuyas se mantienen)
        platosBtn.addActionListener(e -> new Platos().setVisible(true));
        mesasBtn.addActionListener(e -> new Mesas().setVisible(true));
        pedidosBtn.addActionListener(e -> new Pedidos().setVisible(true));
        reportesBtn.addActionListener(e -> new Reportes().setVisible(true));
        FacturacionBtn.addActionListener(e -> new Facturacion().setVisible(true));

        salirBtn.addActionListener(e -> {

            int opcion = JOptionPane.showConfirmDialog(
                    null,
                    "¿Desea salir del sistema?",
                    "Confirmar salida",
                    JOptionPane.YES_NO_OPTION
            );

            if(opcion == JOptionPane.YES_OPTION){
                System.exit(0);
            }

        });
    }

    private void crearDashboard(){

        JPanel fondo = new JPanel(new GridBagLayout());
        fondo.setBackground(new Color(240,240,240));

        JPanel grid = new JPanel(new GridLayout(2,3,30,30));
        grid.setPreferredSize(new Dimension(600,300));
        grid.setBackground(new Color(240,240,240));

        grid.add(crearTarjeta("PLATOS"));
        grid.add(crearTarjeta("MESAS"));
        grid.add(crearTarjeta("PEDIDOS"));
        grid.add(crearTarjeta("REPORTES"));
        grid.add(crearTarjeta("FACTURACIÓN"));
        grid.add(new JPanel());

        fondo.add(grid);

        add(fondo, BorderLayout.CENTER);
    }

    private JPanel crearTarjeta(String texto){

        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createLineBorder(new Color(220,220,220)));
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabel icono = new JLabel("⬤", SwingConstants.CENTER);
        icono.setFont(new Font("Segoe UI",Font.BOLD,42));
        icono.setForeground(new Color(52,120,246));

        JLabel titulo = new JLabel(texto, SwingConstants.CENTER);
        titulo.setFont(new Font("Segoe UI",Font.BOLD,16));

        card.add(icono, BorderLayout.CENTER);
        card.add(titulo, BorderLayout.SOUTH);

        card.addMouseListener(new MouseAdapter(){

            public void mouseEntered(MouseEvent e){
                card.setBackground(new Color(235,240,255));
            }

            public void mouseExited(MouseEvent e){
                card.setBackground(Color.WHITE);
            }

        });

        return card;
    }

    private JButton crearBotonMenu(String texto){

        JButton btn = new JButton(texto);

        btn.setMaximumSize(new Dimension(180,40));
        btn.setFont(new Font("Segoe UI",Font.BOLD,13));

        Color normal = new Color(52,120,246);
        Color hover = new Color(70,140,255);

        btn.setBackground(normal);
        btn.setForeground(Color.WHITE);

        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);

        btn.addMouseListener(new MouseAdapter(){

            public void mouseEntered(MouseEvent e){
                btn.setBackground(hover);
            }

            public void mouseExited(MouseEvent e){
                btn.setBackground(normal);
            }

        });

        return btn;
    }

    private JButton crearBotonSalir(String texto){

        JButton btn = new JButton(texto);

        btn.setMaximumSize(new Dimension(180,40));
        btn.setFont(new Font("Segoe UI",Font.BOLD,13));

        btn.setBackground(new Color(200,60,60));
        btn.setForeground(Color.WHITE);

        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);

        return btn;
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new MainMenu().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
